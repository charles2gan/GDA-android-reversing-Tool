package com.gda.api;
// android-class infomation class
public class ClassInfo{
	public int idx =0;
	public String className="";
	public String modifiedClassName="";
	public String classFullName="";
	public int sourceFileIdx= 0 ;
	public int superclassIdx= 0;
	public String classCode="";
	public int[] subClassList;
	public ClassInfo(){
		super();
	}   
}

